import Diagram from './diagram'

export{
    Diagram
}