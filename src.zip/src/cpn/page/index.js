import Fetch from "./fecth";
import InputPost from "./input-post";
import InputPut from "./input-put"
import ImportData from "./import";
export {
    Fetch, 
    InputPost,
    InputPut,
    ImportData
}