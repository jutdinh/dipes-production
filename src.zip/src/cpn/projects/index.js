import Projects from "./projects";
import ProjectsCard from "./projectcard"
import ProjectDetail from "./projectcard-detail"

export {
    Projects,
    ProjectsCard,
    ProjectDetail
}