
import defaultBranch from './default';
import LangsBranch from './langs';

export {
    defaultBranch,
    LangsBranch
}